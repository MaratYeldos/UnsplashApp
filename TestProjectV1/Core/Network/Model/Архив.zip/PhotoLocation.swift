//
//  PhotoLocation.swift
//  TestProjectV1
//
//  Created by Yeldos Marat on 05.01.2023.
//

import Foundation

struct PhotoLocation: Codable {
    let city: String?
    let country: String?
}
